</div>
</body>

<footer>
	©2019 SEG - Todos os direitos reservados

	<script src="js/jquery.js"></script>
	<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<script>
	$(document).ready( function () {
    	$('#alunos').DataTable();
    	$('#notas').DataTable();
	} );

</script>

</footer>

