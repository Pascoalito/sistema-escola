<div id="tituloHOME">

	<h1>Bem vindo ao sistema de ensino golfinho</h1>
	<br><br><br><br>
</div>

<div id="centerimage">
	<img src="imgs/golf.png">
</div>